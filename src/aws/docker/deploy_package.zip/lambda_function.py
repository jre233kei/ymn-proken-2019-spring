import fasttext
def lambda_handler(event, context):
    return "Hello from lambda docker"
